<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="Cyberlord" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <!-- Favicon-->
     <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/images/1.ico')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
     <!-- Font Awesome icons (free version)-->
     <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
       <?php echo $__env->yieldContent('nav'); ?>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success text-success text-center mx-5">
            <?php echo e(session()->get('success')); ?>

           </div>
           <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-danger text-danger text-center mx-5">
            <?php echo e(session()->get('error')); ?>

           </div>
           <?php endif; ?>
            <main  class="py-4 ">
                <?php if(auth()->guard()->check()): ?>
                <div class="container-fluid">
                    <div class="row">
                        <?php echo $__env->yieldContent('adminnav'); ?>
                        <div class="col-md-10">
                        <?php echo $__env->yieldContent('content'); ?>
                         </div>
                        </main>
                    </div>
               </div>
                <?php else: ?>
                <?php echo $__env->yieldContent('content'); ?>
                <?php endif; ?>

           <div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


    </div>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/layouts/app.blade.php ENDPATH**/ ?>