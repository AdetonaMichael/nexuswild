<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="Cyberlord" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <!-- Favicon-->
     <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/1.jpg')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
     <!-- Font Awesome icons (free version)-->
     <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
       <?php echo $__env->yieldContent('nav'); ?>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success text-success text-center mx-5">
            <?php echo e(session()->get('success')); ?>

           </div> 
           <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-danger text-danger text-center mx-5">
            <?php echo e(session()->get('error')); ?>

           </div> 
           <?php endif; ?>
            <main class="py-4">
                <?php if(auth()->guard()->check()): ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                        <?php echo $__env->yieldContent('content'); ?>
                         </div>
                        </main>
                    </div>
               </div>
                <?php else: ?>
                <?php echo $__env->yieldContent('content'); ?>
                <?php endif; ?>

           <div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
   

    </div>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/layouts/bloghome.blade.php ENDPATH**/ ?>