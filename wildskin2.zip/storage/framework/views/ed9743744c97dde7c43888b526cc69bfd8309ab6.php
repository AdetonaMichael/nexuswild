
<?php $__env->startSection('title'); ?>
NexusWildSkinCare |Profile Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminnav'); ?>
 <?php echo $__env->make('partials.myadminav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-default">
  <div class="card-header">
    <i class="fa fa-user fa-2x" aria-hidden="true"></i> USERS
  </div>
  <div class="card-body">
    <?php if($users->count()>0): ?>
    <table class="table table-striped table-default">
      <thead>
        <th scope="col">Image</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Role</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
            <td><img src="<?php echo e(Gravatar::src($user->email)); ?>" alt="User Gravater"></td>
            <td><p><?php echo e($user->name); ?></p></td>
            <td><?php echo e($user->email); ?></td>
             <td><?php echo e($user->role); ?></td>
             <td>
                 <?php if(!$user->isAdmin()): ?>
                <form action="<?php echo e(route('users.make-admin', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success btn-sm">Make Admin</button>
                
                </form>
                 <?php endif; ?>
                </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php else: ?>
    <h3 class="text-center">No Users Yet</h3>
    <?php endif; ?>
  
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/users/index.blade.php ENDPATH**/ ?>