
<?php $__env->startSection('adminnav'); ?>
<div class="col-md-2">
    <ul class="list-group">
        <li class="list-group-item">
            <a href="<?php echo e(route('posts.index')); ?>">Post</a>
        </li>
          <?php if(auth()->user()->isAdmin()): ?>
          <li class="list-group-item">
             <a href="<?php echo e(route('users.index')); ?>">Users</a>
         </li>
          <?php endif; ?>
        <li class="list-group-item">
            <a href="<?php echo e(route('categories.index')); ?>">Categories</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('tags.index')); ?>">Tags</a>
        </li>
    </ul>
    <ul class="list-group mt-5">
        <li class="list-group-item">
            <a href="<?php echo e(route('trashed-posts.index')); ?>">Trashed Post</a>
        </li>
    </ul>
    <ul class="list-group mt-5">
        <li class="list-group-item">
            <a href="/">Home</a>
        </li>
    </ul>
    <ul class="list-group mt-5">
        <li class="list-group-item">
            <a href="/home">Blog</a>
        </li>
    </ul>
 </div>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Profile')); ?></div>
                <div class="card-body">
                    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <form action="<?php echo e(route('users.update-profile')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="about">About Me</label>
                        <textarea class="form-control" name="about" id="about" cols="5" rows="5" ><?php echo e($user->name); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Upadate Profile</button>
                   </form>
                 </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/users/edit.blade.php ENDPATH**/ ?>