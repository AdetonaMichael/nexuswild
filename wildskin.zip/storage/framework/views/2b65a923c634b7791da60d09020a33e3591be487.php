
<?php $__env->startSection('nav'); ?>
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="/"><img src="\images\nexus.svg" width="150" height="100" style="border-radius:75%" height="50" alt="Nexus Wild Skin Care" /></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ms-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link" href="/home">Blog</a></li>
                        <li class="nav-item"><a class="nav-link" href="/#services">Services</a></li>
                        <li class="nav-item"><a class="nav-link" href="/#portfolio">Portfolio</a></li>
                        <li class="nav-item"><a class="nav-link" href="/#about">About</a></li>
                    </ul>
								<ul class="navbar-nav ">
				<!-- Authentication Links -->
				<?php if(auth()->guard()->guest()): ?>
					<?php if(Route::has('login')): ?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
						</li>
					<?php endif; ?>

					<?php if(Route::has('register')): ?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
						</li>
					<?php endif; ?>
				<?php else: ?>
					<li class="nav-item dropdown">
						
						<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
							<?php echo e(Auth::user()->name); ?>

						  </button>

						<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
							<a class="dropdown-item" href="<?php echo e(route('users.edit-profile')); ?>">
								My Profile
							</a>
							<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
							   onclick="event.preventDefault();
											 document.getElementById('logout-form').submit();">
								<?php echo e(__('Logout')); ?>

							</a>
							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
								<?php echo csrf_field(); ?>
							</form>
						</div>
					</li>
				<?php endif; ?>
			</ul>
			
                </div>
            </div>
        </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="site-content">
    	<!-- Home Jumbotron
    ================================================== -->
	<section class="intro">
		<div class="wrapintro">
			<h1>NEXUS WILD SKIN CARE</h1>
			<h2 class="lead">Why You Just Want To Tell the Story Behind your Beauty</h2>
			<h3 class="lead text-white"><?php echo e($post->name); ?></h3>
			
            
		</div>
		</section>
		<div id="carouselExampleSlidesOnly" class="carousel slide d-md-none" data-bs-ride="carousel">
			<div class="carousel-inner">
			  <div class="carousel-item active">
				<img src="https://cdn.pixabay.com/photo/2016/11/29/10/10/girl-1868930_960_720.jpg" class="d-block w-100 h-70 " alt="woman 1">
			  </div>
			  <div class="carousel-item">
				<img src="https://cdn.pixabay.com/photo/2016/04/21/22/26/mystical-portrait-of-a-girl-1344632_960_720.jpg" class="d-block w-100 h-70" alt="woman 2">
			  </div>
			  <div class="carousel-item">
				<img src="https://cdn.pixabay.com/photo/2018/01/21/14/16/woman-3096664_960_720.jpg" class="d-block w-100 h-70" alt="woman 3">
			  </div>
			</div>
		  </div>
	<div class="container">
		<!-- Content
    ================================================== -->
		<div class="main-content">
			<!-- Begin Article
            ================================================== -->
			<div class="row">			
				<!-- Post -->
				<div class="col-sm-8">
					<div class="mainheading">
						<!-- Post Categories -->
                        <div class="after-post-tags">
							<ul class="tags">
                        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
								<a href="<?php echo e(route('blog.tag',$tag->id)); ?>"><?php echo e($tag->name); ?></a>
                                </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
						<!-- End Categories -->
						<!-- Post Title -->
                        <hr/>
						<h1 class="posttitle"><?php echo e($post->title); ?></h1>
                        <hr/>
					</div>
					<!-- Post Featured Image -->
					<img class="featured-image img-fluid" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
					<!-- End Featured Image -->
					<!-- Post Content -->
					<div class="article-post">
						{<?php echo $post->content; ?>}
						<div class="clearfix">
						</div>
					</div>
					<!-- Post Date -->
					<p>
						<small>
						<span class="post-date"><time class="post-date text-danger" datetime="2018-01-12"><?php echo e($post->published_at); ?></time></span>
						</small>
					</p>
		           <hr/>
					<!-- Author Box -->
					<div class="row post-top-meta">
						<div class="col-md-2">
							<img src="<?php echo e(Gravatar::src($post->user->email)); ?>" alt="User Gravater">
						</div>
						<div class="col-md-10">
							<a target="_blank" class="link-dark" href="#"><?php echo e($post->user->name); ?></a><a target="_blank" href="https://twitter.com/wowthemesnet" class="btn follow">Follow</a>
							<span class="author-description"><?php echo e($post->user->about); ?></span>
						</div>
					</div>
                    <hr/>
					<!-- Begin Comments
                    ================================================== -->
                    
                    <!--End Comments
                    ================================================== -->
				</div>
				<!-- End Post -->
                
                <!-- Sidebar -->
				<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Sidebar -->
                
			</div>

		</div>
	</div>
	<!-- /.container -->

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<script src=<?php echo e(asset('js/scripts.js')); ?>></script>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-61210f2ea766e0e5"></script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.bloghome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/blog/show.blade.php ENDPATH**/ ?>