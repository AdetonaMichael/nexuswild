
<?php $__env->startSection('adminnav'); ?>
<?php echo $__env->make('partials.myadminav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-2">
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success"><i class="fa fa-plus mr-2" aria-hidden="true"></i> Add Post</a>
</div>

<div class="card card-default">
  <div class="card-header">
      Posts
  </div>
  <div class="card-body">
    <?php if($posts->count()>0): ?>
    <table class="table table-striped">
      <thead>
        <th scope="col">Image</th>
        <th scope="col">Title</th>
        <th scope="col">Category</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><img src="<?php echo e(asset('storage/'.$post->image)); ?>" width=60 height=60></td>
            <td><p><?php echo e($post->title); ?></p></td>
            <td><a href="<?php echo e(route('categories.edit', $post->category->id)); ?>"><?php echo e($post->category->name); ?></td>
            <?php if(!$post->trashed()): ?>
            <td>
              <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info btn-sm">Edit</a>
            </td>
            <?php else: ?>
              
              <td>
            <form action="<?php echo e(route('restore-posts', $post->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <button type="submit" class="btn btn-info btn-sm text-white">Restore</button>

            </form>
            </td>
              <?php endif; ?>
            
            <td>
              <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              
                <button type="submit" class="btn btn-danger btn-sm">
                  <?php echo e($post->trashed() ? 'Delete':'Trash'); ?><i class="fab fa-trash" aria-hidden="true"></i></button>
  
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php else: ?>
    <h3 class="text-center">No Post At this Moment</h3>
    <?php endif; ?>
  
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\wildskin2\resources\views/posts/index.blade.php ENDPATH**/ ?>